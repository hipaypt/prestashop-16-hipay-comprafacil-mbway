<?php

namespace HipayMbway;
use HipayMbway\MbwayRequest;

/**
 * Description of MbwayRequestRefund
 *
 * @author hipay.pt
 */
class MbwayRequestRefund extends MbwayRequest{


}
